import {Component, OnChanges} from '@angular/core';

@Component({
  selector: 'list',
  styleUrls: ['./list.component.css'],
  templateUrl: './list.component.html'
})
export class ListComponent implements OnChanges{
  /**
   * You will need to set up some input variables
   * https://angular.io/tutorial/toh-pt3#the-hero-property-is-an-input-property
   * 
   * and a change event listener.
   * You should format your data here.
   */

  ngOnChanges() {};
}